require('./a.txt');
require('./b.txt');
