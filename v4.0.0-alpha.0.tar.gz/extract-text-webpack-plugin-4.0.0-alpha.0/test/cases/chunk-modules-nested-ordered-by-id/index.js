require('./c.txt');
require('./a.js');
