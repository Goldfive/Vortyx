require('./b.txt');
require('./a.txt');
