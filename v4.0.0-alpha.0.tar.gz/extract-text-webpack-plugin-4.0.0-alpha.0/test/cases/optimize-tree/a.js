require.ensure([], () => {
  require('./a.txt');
});

a = {};
