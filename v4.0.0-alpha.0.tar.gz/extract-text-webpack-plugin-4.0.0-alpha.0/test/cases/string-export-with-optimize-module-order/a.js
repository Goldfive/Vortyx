require("./module")();
module.exports = "a\n";
