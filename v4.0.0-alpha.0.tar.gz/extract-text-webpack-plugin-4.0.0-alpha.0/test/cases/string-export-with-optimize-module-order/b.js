require("./module")();
module.exports = "b\n";
