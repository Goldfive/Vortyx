require('./a.txt');
require('./file');
require('./b.txt');
