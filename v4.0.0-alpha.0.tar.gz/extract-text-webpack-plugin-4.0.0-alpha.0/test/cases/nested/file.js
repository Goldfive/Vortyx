require('./a.txt');
require('./b.txt');
require('./c.txt');
require('./d.txt');
