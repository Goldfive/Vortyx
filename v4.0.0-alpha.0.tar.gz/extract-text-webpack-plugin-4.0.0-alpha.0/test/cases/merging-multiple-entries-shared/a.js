require.ensure([], () => {
  require('./a.txt');
});
